<?php

use yii\helpers\Html;
$this->title = 'Админ панель';
?>


<div class="cta-buttons d-flex justify-content-center gap-3">
    <?= Html::a(' Редактирование заявок', ['application/index'], ['class' => 'btn btn-light btn-lg px-4']) ?>

</div>